function [ score ] = giniscore( frac )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

score = ( frac(1) * (1 - frac(1)) );

end

